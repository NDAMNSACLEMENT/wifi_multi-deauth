Wi-Fi Security Sensitization Tool
=================================

This Bash script allows a security analyst to perform a deauthentication demo either:
- On the network they are already connected to (targeting clients), or
- On nearby external Wi-Fi networks (targeting BSSIDs).

REQUIREMENTS:
- Kali Linux or a distro with aircrack-ng installed
- Run as root (sudo)
- Wireless adapter supporting monitor mode

USAGE:
1. chmod +x wifi_sensitization_tool.sh
2. sudo ./wifi_sensitization_tool.sh

AUTHOR: Custom for internal awareness & sensitization use only.
